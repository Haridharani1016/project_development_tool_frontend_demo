import React from 'react'

const Navbar = () => {
  return (
    <div className='bg-white shadow h-14'></div>
  )
}

export default Navbar